# asipro

This little project implements a virtual SImple PROcessor, named SIPRO, which has been developped as a support for an introduction course to compilers.

It contains:
- an emulation program for SIPRO, also named *sipro*, whose source code is located into the *emul* directory
- an assembly program for SIPRO, named *asipro*, whose source code is located into the *asm* directory
- the documentation (in french), located into the *doc* directory
- some examples located into the *examples* directory
